package com.gupaoedu.vip.pattern.proxy.dynamicproxy.jdkproxy;

/**
 * Created by Tom.
 */
public interface IPerson {

    void findLove();

    void buyInsure();

}
