package com.gupaoedu.vip.pattern.proxy.dynamicproxy.gpproxy.client;

/**
 * Created by Tom.
 */
public interface IPerson {

    void findLove();

    void buyInsure();

}
