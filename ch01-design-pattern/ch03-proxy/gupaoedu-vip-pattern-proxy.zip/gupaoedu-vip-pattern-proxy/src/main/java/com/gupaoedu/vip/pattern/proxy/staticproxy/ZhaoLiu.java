package com.gupaoedu.vip.pattern.proxy.staticproxy;

/**
 * Created by Tom.
 */
public class ZhaoLiu implements IPerson {

    public void findLove() {

    }

}
