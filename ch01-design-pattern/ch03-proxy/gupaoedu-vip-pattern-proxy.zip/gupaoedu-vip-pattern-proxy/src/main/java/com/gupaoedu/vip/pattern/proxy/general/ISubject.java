package com.gupaoedu.vip.pattern.proxy.general;

/**
 * Created by Tom.
 */
public interface ISubject {
    void request();
}
