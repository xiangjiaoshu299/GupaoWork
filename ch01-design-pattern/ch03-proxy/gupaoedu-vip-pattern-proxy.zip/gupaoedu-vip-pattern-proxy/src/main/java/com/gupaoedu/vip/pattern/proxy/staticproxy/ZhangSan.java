package com.gupaoedu.vip.pattern.proxy.staticproxy;

/**
 * Created by Tom.
 */
public class ZhangSan implements IPerson {

    public void findLove() {
        System.out.println("儿子要求：肤白貌美大长腿");
    }

}
