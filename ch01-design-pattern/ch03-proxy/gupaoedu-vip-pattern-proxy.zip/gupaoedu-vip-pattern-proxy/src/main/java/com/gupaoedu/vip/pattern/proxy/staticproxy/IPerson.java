package com.gupaoedu.vip.pattern.proxy.staticproxy;

/**
 * Created by Tom.
 */
public interface IPerson {

    void findLove();

}
