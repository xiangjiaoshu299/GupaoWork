package com.gupaoedu.vip.pattern.proxy.dynamicproxy.jdkproxy;


/**
 * Created by Tom.
 */
public class ZhaoLiu implements IPerson {

    public void findLove() {
        System.out.println("赵六要求：有车有房学历高");
    }

    public void buyInsure() {

    }

}
